# How to build an Event Booking App using HTML, CSS, JavaScript and Firebase?

In this tutorial, we are going to build an Event Booking App with HTML, CSS, JavaScript, and Firebase.
Find the [full article](https://www.ibrahima-ndaw.com/blog/build-an-event-booking-app-with-javascript-and-firebase/) on my blog